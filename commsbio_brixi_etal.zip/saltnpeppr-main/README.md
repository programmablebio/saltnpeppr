# SaLT&PepPr

### An Interface-Predicting Language Model for Designing Peptide-Guided Protein Degraders

![saltnpeppr_inference](https://user-images.githubusercontent.com/106272333/196185861-40837a34-2164-4a95-bdf0-30ce9b4b4b9f.png)


Protein-protein interactions (PPIs) are critical for biological processes and predicting the sites of these interactions is useful for both computational and experimental applications. We present a **S**tructure-**a**gnostic **L**anguage **T**ransformer and **Pep**tide **Pr**ioritization (**SaLT&PepPr**) pipeline to predict interaction interfaces from a protein sequence alone for the subsequent generation of peptidic binding motifs. Our model fine-tunes the ESM-2 protein language model (pLM) with a per-position prediction task to identify PPI sites using data from the PDB, and prioritizes motifs which are most likely to be involved within inter-chain binding. By only using amino acid sequence as input, our model is competitive with structural homology-based methods, but exhibits reduced performance compared with deep learning models that input both structural and sequence features. Inspired by our previous results using co-crystals to engineer target-binding “guide” peptides, we curate PPI databases to identify partners for subsequent peptide derivation. Fusing guide peptides to an E3 ubiquitin ligase domain, we demonstrate degradation of endogenous β-catenin, 4E-BP2, and TRIM8, and highlight the nanomolar binding affinity, low off-targeting propensity, and function-altering capability of our best-performing degraders in cancer cells. In total, our study suggests that prioritizing binders from natural interactions via pLMs can enable programmable protein targeting and modulation.

Please read and cite our [manuscript](https://www.nature.com/articles/s42003-023-05464-z) published in *Communications Biology*!

Model weights are available on [Drive](https://drive.google.com/u/1/uc?id=1JVfVTB2g1yOkpySYsb9nvDTHDI4InGaz&export=download)

Data is available on [Zenodo](https://zenodo.org/records/10008581)

We have developed a user-friendly [Colab notebook](https://colab.research.google.com/drive/1g-WBPi8_eWqUdD-BWHdPWLIQ8I9V3Log?usp=sharing) for peptide generation with SaLT&PepPr!

Repository Authors: Garyk Brixi, Sophie Vincoff, and Pranam Chatterjee

Contact: pranam.chatterjee@duke.edu
